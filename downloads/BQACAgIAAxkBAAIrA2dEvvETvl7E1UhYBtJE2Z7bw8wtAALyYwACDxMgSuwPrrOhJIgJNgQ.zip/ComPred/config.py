import os
import logging
from pathlib import Path
from dotenv import load_dotenv

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Получаем абсолютный путь к директории проекта
BASE_DIR = Path(__file__).resolve().parent

# Загружаем переменные окружения из .env файла
env_path = BASE_DIR / '.env'
logger.info(f"Путь к .env файлу: {env_path}")
logger.info(f"Файл существует: {env_path.exists()}")

if not env_path.exists():
    logger.error(f"Файл .env не найден по пути: {env_path}")
    raise FileNotFoundError(f"Файл .env не найден по пути: {env_path}")

# Загружаем переменные окружения
load_dotenv(env_path)

# Читаем содержимое .env файла напрямую для отладки
with open(env_path, 'r') as f:
    env_content = f.read()
    logger.info(f"Содержимое .env файла:\n{env_content}")

# Логируем значения переменных окружения для отладки
logger.info(f"Загруженные переменные окружения:")
logger.info(f"BOT_TOKEN: {os.environ.get('BOT_TOKEN')}")
logger.info(f"ADMIN_ID: {os.environ.get('ADMIN_ID')}")

# Проверяем наличие и корректность переменных окружения
BOT_TOKEN = os.environ.get('BOT_TOKEN')
if not BOT_TOKEN:
    logger.error("BOT_TOKEN не найден в переменных окружения")
    raise ValueError("BOT_TOKEN не найден в переменных окружения")

try:
    ADMIN_ID = int(os.environ.get('ADMIN_ID', '0'))
    if ADMIN_ID == 0:
        logger.error("ADMIN_ID не найден в переменных окружения")
        raise ValueError("ADMIN_ID не найден в переменных окружения")
except (TypeError, ValueError) as e:
    logger.error(f"Некорректное значение ADMIN_ID: {os.environ.get('ADMIN_ID')}")
    raise ValueError(f"Некорректное значение ADMIN_ID: {os.environ.get('ADMIN_ID')}") from e

# Добавляем переменную SUPER_ADMIN
SUPER_ADMIN = '257027965'
logger.info(f"SUPER_ADMIN: {SUPER_ADMIN}")

# Константы для расчетов
MY_CITY = 'Тверь, Центральная'
BUSINESS_TRIP_COST = 8000.0
CRITICAL_DISTANCE = 300.0
CRITICAL_COUNT_OBJECT = 3
DISTANCE_COEFFICIENT = 1.3

# Redis configuration
REDIS_HOST = os.getenv('REDIS_HOST', 'localhost')
REDIS_PORT = int(os.getenv('REDIS_PORT', 6379))
REDIS_DB = int(os.getenv('REDIS_DB', 0))
REDIS_URL = f"redis://{REDIS_HOST}:{REDIS_PORT}/{REDIS_DB}"

# Константы для расчетов
MY_CITY = 'Тверь, Центральная'
BUSINESS_TRIP_COST = 8000.0
CRITICAL_DISTANCE = 300.0
CRITICAL_COUNT_OBJECT = 3
DISTANCE_COEFFICIENT = 1.3

# Константы для цены за километр в зависимости от удаленности объекта
KM_COST_BRACKETS = {(0, 100): 25,(101, 300): 30,(301, 500): 35,(501, 1000): 40,(1001, float('inf')): 45}

# Константы для цены за метр протяженности в зависимости от протяженности объекта
LENGTH_COST_BRACKETS = {(0, 1000): 3.5,(1001, 5000): 3,(5001, 10000): 2.5,(10001, float('inf')): 2}

# Константы для цены за квадратный метр площади ОКС в зависимости от площади ОКС
OKS_AREA_COST_BRACKETS = {(0, 150): 0, (151, 500): 35, (501, 1000): 30, (1001, float('inf')): 25}

# Константы для цены за другой объект в зависимости от количества других объектов
OTHER_OBJECT_COST_BRACKETS = {(0, 5): 1000,(6, 10): 900,(11, 20): 800,(21, float('inf')): 700}

# Константы для цены за объект в зависимости от количества объектов
OBJECT_COST_BRACKETS = {(1, 2): 10000,(2, 3): 9500,(4, 5): 9000,(6, 10): 8500,(11, 20): 8000,(21, float('inf')): 7500}

# Константы для стоимости за гектар земельного участка
ZU_SQM_COST_BRACKETS = {(0, 1000): 20000,(1001, 1500): 19000, (1501, 3000): 18000, (3001, 5000): 14000,(5001, 50000): 7000,(50001, 100000): 4000,(100001, 500000): 2000,(500001, 1000000): 1025,(1000001, 5000000): 1000,(5000001, 10000000): 950,(10000001, 20000000): 900,(20000001, 50000000): 850,(50000001, 100000000): 800,(100000001, float('inf')): 750}

def update_config_variable(variable_name, new_value):
    global BUSINESS_TRIP_COST, CRITICAL_DISTANCE, CRITICAL_COUNT_OBJECT, KM_COST_BRACKETS, LENGTH_COST_BRACKETS, OKS_AREA_COST_BRACKETS, OTHER_OBJECT_COST_BRACKETS, OBJECT_COST_BRACKETS, ZU_SQM_COST_BRACKETS, MY_CITY, DISTANCE_COEFFICIENT

    if variable_name in ["BUSINESS_TRIP_COST", "CRITICAL_DISTANCE", "CRITICAL_COUNT_OBJECT", "DISTANCE_COEFFICIENT"]:
        new_value = float(new_value)

    if variable_name == "BUSINESS_TRIP_COST":
        BUSINESS_TRIP_COST = new_value
    elif variable_name == "CRITICAL_DISTANCE":
        CRITICAL_DISTANCE = new_value
    elif variable_name == "CRITICAL_COUNT_OBJECT":
        CRITICAL_COUNT_OBJECT = new_value
    elif variable_name == "KM_COST_BRACKETS":
        KM_COST_BRACKETS = eval(new_value)
    elif variable_name == "LENGTH_COST_BRACKETS":
        LENGTH_COST_BRACKETS = eval(new_value)
    elif variable_name == "OKS_AREA_COST_BRACKETS":
        OKS_AREA_COST_BRACKETS = eval(new_value)
    elif variable_name == "OTHER_OBJECT_COST_BRACKETS":
        OTHER_OBJECT_COST_BRACKETS = eval(new_value)
    elif variable_name == "OBJECT_COST_BRACKETS":
        OBJECT_COST_BRACKETS = eval(new_value)
    elif variable_name == "ZU_SQM_COST_BRACKETS":
        ZU_SQM_COST_BRACKETS = eval(new_value)
    elif variable_name == "MY_CITY":
        MY_CITY = new_value
    elif variable_name == "DISTANCE_COEFFICIENT":
        DISTANCE_COEFFICIENT = new_value
    else:
        raise ValueError(f"Неизвестная переменная: {variable_name}")

    # Обновление значения в файле config.py
    update_config_file(variable_name, new_value)

def update_config_file(variable_name, new_value):
    with open("config.py", "r", encoding="utf-8") as file:
        lines = file.readlines()

    with open("config.py", "w", encoding="utf-8") as file:
        for line in lines:
            if line.startswith(variable_name):
                file.write(f"{variable_name} = {repr(new_value)}\n")
            else:
                file.write(line)